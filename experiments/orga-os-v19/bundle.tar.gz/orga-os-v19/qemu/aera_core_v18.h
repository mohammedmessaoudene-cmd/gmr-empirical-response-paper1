#ifndef AERA_CORE_V18_H
#define AERA_CORE_V18_H

#include <stdbool.h>
#include <stdint.h>

#define AERA_CORE_V18_DOMAIN 0x41455241u /* AERA */

typedef struct {
    uint64_t authority_version;
    uint64_t body_uid;
    uint64_t epoch_id;
    uint64_t generation;
    bool valid;
} AeraCorePermitV18;

typedef struct {
    uint64_t body_uid;
    uint64_t epoch_id;
    uint64_t generation;
    uint64_t authority_version;
    uint64_t last_nonce;
    uint64_t certificate_sequence;
    uint64_t certificate_uid;
    uint64_t certificate_epoch;
    uint64_t certificate_generation;
    uint64_t reflex_certificate_sequence;
    uint64_t committed_actions;
    uint64_t blocked_actions;
    uint64_t stale_attempts;
    uint64_t revocations;
    uint64_t probes;
    bool attestation_valid;
    bool certificate_valid;
    bool reflex_valid;
    bool quarantine;
    bool learned_mask;
    bool cached_action_valid;
} AeraCoreV18;

void aera_core_v18_init(AeraCoreV18 *s, uint64_t body_uid);
void aera_core_v18_revoke(AeraCoreV18 *s);
void aera_core_v18_reset(AeraCoreV18 *s);
void aera_core_v18_hotswap(AeraCoreV18 *s, uint64_t new_body_uid);
void aera_core_v18_probe(AeraCoreV18 *s);
void aera_core_v18_replay(AeraCoreV18 *s);
bool aera_core_v18_attest(AeraCoreV18 *s, uint64_t nonce);
bool aera_core_v18_certificate(AeraCoreV18 *s, uint64_t sequence);
bool aera_core_v18_reflex(AeraCoreV18 *s, uint64_t sequence);
bool aera_core_v18_begin(AeraCoreV18 *s, AeraCorePermitV18 *permit);
bool aera_core_v18_commit(AeraCoreV18 *s, const AeraCorePermitV18 *permit);
bool aera_core_v18_authorized(const AeraCoreV18 *s);
bool aera_core_v18_invariants(const AeraCoreV18 *s);

#endif
