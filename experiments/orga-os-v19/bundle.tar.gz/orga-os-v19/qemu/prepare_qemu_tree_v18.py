#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
import shutil


def append_once(path: Path, text: str) -> None:
    content = path.read_text()
    if text.strip() not in content:
        if not content.endswith("\n"):
            content += "\n"
        path.write_text(content + text.rstrip() + "\n")


def insert_before_once(path: Path, marker: str, text: str) -> None:
    content = path.read_text()
    if text.strip() in content:
        return
    if marker not in content:
        raise RuntimeError(f"marker not found in {path}: {marker!r}")
    path.write_text(content.replace(marker, text.rstrip() + "\n\n" + marker, 1))


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--qemu-src", required=True)
    p.add_argument("--bundle", required=True)
    a = p.parse_args()
    qemu = Path(a.qemu_src).resolve()
    bundle = Path(a.bundle).resolve()
    required = [qemu / "configure", qemu / "hw/misc/meson.build", qemu / "tests/qtest/meson.build"]
    for item in required:
        if not item.exists():
            raise RuntimeError(f"not a QEMU source tree: missing {item}")

    for name in ["orga-aera-v18.c", "aera_core_v18.c", "aera_core_v18.h"]:
        shutil.copy2(bundle / name, qemu / "hw/misc" / name)
    shutil.copy2(bundle / "orga-aera-v18-test.c", qemu / "tests/qtest/orga-aera-v18-test.c")

    append_once(qemu / "hw/misc/Kconfig", (bundle / "Kconfig-v18.fragment").read_text())
    append_once(qemu / "hw/misc/meson.build", (bundle / "meson-hw-v18.fragment").read_text())
    insert_before_once(
        qemu / "tests/qtest/meson.build",
        "qos_test_ss = ss.source_set()",
        (bundle / "meson-qtest-v18.fragment").read_text(),
    )
    print(f"prepared {qemu}")


if __name__ == "__main__":
    main()
