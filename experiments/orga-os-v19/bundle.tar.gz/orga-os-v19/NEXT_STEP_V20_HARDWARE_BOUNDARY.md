# V20 — conditionnelle uniquement

V20 ne sera autorisée que si TLC, QEMU/QTest et IOMMU passent sur les deux runners
et si un évaluateur distinct reproduit le paquet. Elle construirait alors une VM
confinée avec un driver invité minimal, puis un banc FPGA sans accès au PC personnel.
Aucune étape matérielle ne doit commencer sur la base d'une CI partielle.
